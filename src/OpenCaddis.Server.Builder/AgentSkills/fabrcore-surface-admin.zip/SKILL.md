---
name: fabrcore-surface-admin
description: >
  Build, host, extend, or troubleshoot the commercial FabrCore.Surface.Admin Razor class
  library: principal/agent/blueprint management, GraphRAG and Memory administration,
  verifiable execution, incidents, remote admin clients, Forge connect routing, and explicit
  admin route/component registration.
---

# FabrCore Surface Admin

`FabrCore.Surface.Admin` is the commercial administrative UI layered over the OSS
`FabrCore.Surface` command center and open FabrCore admin protocols.

## Boundary

- Keep `/surface`, chat, Adaptive Cards, shared command-center services, and Swarm runtime types
  in the OSS `FabrCore.Surface` package.
- Keep interactive management and admin pages in `FabrCore.Surface.Admin`.
- Consume `FabrCore.Surface`, `FabrCore.Services.Contracts`, and
  `FabrCore.Services.Memory` as OSS NuGet packages in Release builds.
- Do not reintroduce local copies of OSS Surface, Memory, or GraphRAG projects.

## Routes

| Route | Component |
|---|---|
| `/surface/management` and `/principals` | `SurfacePrincipalsPage` |
| `/surface/management/agents` | `SurfaceAgentsPage` |
| `/surface/management/blueprints` | `SurfaceAdminPage` |
| `/surface/knowledge` | `SurfaceAdminPage` |
| `/surface/memory` | `SurfaceMemoryPage` |
| `/surface/execution` and `/{TraceId}` | verifiable-execution pages |
| `/surface/execution/incidents` | `SurfaceIncidentWorkbenchPage` |

Register components and routes explicitly:

```csharp
builder.AddFabrCoreSurface(options =>
{
    options.FabrCoreHostUrl = "https://fabrcore-host.example.com";
});

builder.Services.AddFabrCoreSurfaceAdminComponents(
    graphRag =>
    {
        graphRag.Mode = SurfaceGraphRagAdminMode.Remote;
        graphRag.ApiKey = builder.Configuration["FabrCoreAdminKey"];
    },
    memory =>
    {
        memory.Mode = MemoryAdminClientMode.Remote;
        memory.BaseAddress = "https://fabrcore-host.example.com";
        memory.ApiKey = builder.Configuration["FabrCoreAdminKey"];
    });

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode()
    .AddFabrCoreSurfaceAdminRoutes();
```

`AddFabrCoreSurfaceAdminRoutes()` also adds the base Surface route assembly and deduplicates route
registration. Do not add either assembly through raw `AddAdditionalAssemblies`.

## Remote security

Memory and GraphRAG endpoints require the OSS Host's `FabrCoreAdmin` bearer policy.
`x-user-handle` is ACL/audit context, not authentication.

- `RemoteGraphRagAdminClient` uses `SurfaceGraphRagAdminOptions.ApiKey`.
- `RemoteMemoryAdminClient` uses `MemoryAdminClientOptions.ApiKey`.
- Keep keys in user secrets or a vault.
- In Forge, `ForgeConnectHttpMessageHandler` removes caller Authorization, uses the durable
  connect broker, and stamps the authenticated Forge actor as `x-user-handle`.

## Forge hosting

Forge configures a single target with:

```json
{
  "Forge": {
    "AdminTarget": {
      "ClusterId": "<guid>",
      "Environment": "Production"
    }
  }
}
```

The current app routes named Surface clients through the connect handler. Preserve that named
client list when adding a new remote admin client.

## Validation

Build and test against packages, not only sibling source:

```powershell
dotnet test C:\repos\fabrcore-v365\src\FabrCore.Surface.Admin.Tests\FabrCore.Surface.Admin.Tests.csproj `
  -c Release `
  /p:UseLocalFabrCoreSource=false `
  /p:FabrCoreOssVersion=<local-version>
```

Also build the full commercial solution in package mode when changing routes, dependencies, or
Forge connect registration.
