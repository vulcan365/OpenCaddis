---
name: fabrcore-plugins-tools
description: >
  Build FabrCore plugins and standalone tools — IFabrCorePlugin, PluginAlias, ToolAlias, tool calling patterns,
  plugin settings, DI access, disposable resources, and inter-agent communication from plugins.
  Triggers on: "build plugin", "create plugin", "IFabrCorePlugin", "PluginAlias", "standalone tool", "ToolAlias",
  "tool calling", "AIFunctionFactory", "add tools to agent", "[Description]", "plugin settings",
  "GetPluginSetting", "plugin DI", "tool description", "tool method",
  "AgentMessage.IsSystemMessage", "SystemMessageTypes", "_thinking", "_status",
  "FabrCoreCapabilities", "FabrCoreNote", "plugin capabilities", "tool capabilities",
  "IFabrCoreStorageProvider", "typed storage", "entity storage", "IVerifiableExecutionContext",
  "attested external effect", "ExternalDbEffect", "ExternalHttpCall", "ExternalStorageEffect",
  "ExternalLibraryCall", "RecordDbEffectAsync", "RecordHttpCallAsync", "RecordStorageEffectAsync",
  "RecordLibraryCallAsync", "VerifiableExecutionHash".
  Do NOT use for: MCP integration — use fabrcore-mcp.
  Do NOT use for: agent lifecycle — use fabrcore-agent.
allowed-tools: "Bash(dotnet:*) Bash(mkdir:*) Bash(ls:*) Bash(pwsh:*) Bash(powershell:*) Bash(git:*) Bash(dir:*)"
---

# FabrCore Plugins and Standalone Tools

## When to Use a Plugin vs. a Standalone Tool

| Aspect | Plugin | Standalone Tool |
|--------|--------|-----------------|
| Implementation | Class with `IFabrCorePlugin` | Static method |
| State | Yes — holds injected services, config, connections | No — pure function |
| DI Support | `IServiceProvider` in `InitializeAsync` | None (static context) |
| Lifecycle | `InitializeAsync` called once per agent | No lifecycle |
| Discovery | `[PluginAlias("name")]` on class | `[ToolAlias("name")]` on static method |
| Registry Metadata | `[Description]`, `[FabrCoreCapabilities]`, `[FabrCoreNote]` on class | `[Description]`, `[FabrCoreCapabilities]`, `[FabrCoreNote]` on method |
| Use Cases | API integrations, DB access, HTTP clients, stateful workflows | String formatting, math, date/time, simple conversions |

## Building a Plugin

Plugins are stateful tool collections that implement `IFabrCorePlugin`.

### Naming Convention
- **Class name:** PascalCase ending in `Plugin` (e.g., `GitHubPlugin`)
- **Plugin alias:** kebab-case or PascalCase (e.g., `"github"`) — used in `[PluginAlias]` and `AgentConfiguration.Plugins`

### Plugin Template

```csharp
using System.ComponentModel;
using FabrCore.Core;
using FabrCore.Sdk;

[PluginAlias("my-plugin")]
[Description("Data lookup and transformation plugin for my-service")]
[FabrCoreCapabilities("Provides data lookup and transformation tools for the my-service API.")]
[FabrCoreNote("Requires my-plugin:ApiKey in Args for authentication.")]
public class MyPlugin : IFabrCorePlugin
{
    private IFabrCoreAgentHost _agentHost = default!;
    private ILogger<MyPlugin> _logger = default!;

    public Task InitializeAsync(AgentConfiguration config, IServiceProvider serviceProvider)
    {
        _agentHost = serviceProvider.GetRequiredService<IFabrCoreAgentHost>();
        _logger = serviceProvider.GetRequiredService<ILogger<MyPlugin>>();

        // Read plugin-specific configuration
        var apiKey = config.GetPluginSetting("my-plugin", "ApiKey");
        var timeout = config.GetPluginSetting("my-plugin", "Timeout", "30");

        return Task.CompletedTask;
    }

    [Description("Short, clear description of what this tool does")]
    public async Task<string> MyTool(
        [Description("Parameter description")] string input,
        [Description("Optional limit")] int limit = 10)
    {
        _logger.LogInformation("MyTool called with input: {Input}", input);
        return "result";
    }
}
```

### Plugin Lifecycle

1. **Discovery** — `FabrCoreRegistry` scans assemblies for `[PluginAlias]` at startup; `[FabrCoreCapabilities]` and `[FabrCoreNote]` metadata is included in the registry
2. **Resolution** — `FabrCoreToolRegistry.ResolvePluginToolsAsync()` instantiates the plugin
3. **Initialization** — `InitializeAsync(config, serviceProvider)` called with agent's config
4. **Tool Extraction** — Public methods with `[Description]` become `AITool` instances; method names and descriptions are included in the registry
5. **Disposal** — If plugin implements `IDisposable` or `IAsyncDisposable`, disposed on agent deactivation

### Registry Metadata Attributes

Decorate plugins and standalone tools with `[FabrCoreCapabilities]` and `[FabrCoreNote]` so the discovery registry exposes what they do. This metadata is returned by the `/fabrcoreapi/discovery` endpoint.

| Attribute | Targets | Multiplicity | Purpose |
|-----------|---------|-------------|---------|
| `[Description("...")]` | Class or Method | One | Short summary (from `System.ComponentModel`). On plugin classes it describes the plugin; on tool methods it describes the tool |
| `[FabrCoreCapabilities("...")]` | Class or Method | One | Describes what the plugin/tool provides in detail |
| `[FabrCoreNote("...")]` | Class or Method | Multiple | Usage instructions, prerequisites, or limitations |
| `[FabrCoreHidden]` | Class or Method | One | Hides the plugin/tool from the discovery endpoint (still usable, just not listed) |

**On a plugin class** (applies to the entire plugin):
```csharp
[PluginAlias("weather")]
[Description("Real-time weather data plugin")]
[FabrCoreCapabilities("Current conditions, forecasts, and severe weather alerts for any location.")]
[FabrCoreNote("Requires weather:ApiKey in Args.")]
[FabrCoreNote("Rate limited to 60 requests per minute per agent.")]
public class WeatherPlugin : IFabrCorePlugin { /* ... */ }
```

**On a standalone tool method:**
```csharp
[ToolAlias("format-currency")]
[Description("Formats a decimal as USD currency")]
[FabrCoreCapabilities("Currency formatting for US locale.")]
[FabrCoreNote("Only supports USD — do not use for international currencies.")]
public static string FormatCurrency([Description("Amount to format")] decimal amount) { /* ... */ }
```

These attributes are optional but strongly recommended for discoverable plugins and tools.

### Plugin Settings Convention

Pass settings via `AgentConfiguration.Args` using `"PluginAlias:Key"` format:

```json
{
  "Handle": "my-agent",
  "Plugins": ["my-plugin"],
  "Args": {
    "my-plugin:ApiKey": "abc123",
    "my-plugin:Timeout": "60",
    "my-plugin:MaxResults": "50"
  }
}
```

Read in the plugin:
```csharp
var apiKey = config.GetPluginSetting("my-plugin", "ApiKey");
var allSettings = config.GetPluginSettings("my-plugin");
// allSettings = { "ApiKey": "abc123", "Timeout": "60", "MaxResults": "50" }
```

### Plugin DI Access

The `IServiceProvider` in `InitializeAsync` includes:
- `IFabrCoreAgentHost` — For inter-agent communication, handle access, and status messages
- `IFabrCoreStorageProvider` — For Host-backed typed entity storage when registered by FabrCore.Host
- `IVerifiableExecutionContext` — Optional; use `FabrCore.Sdk.VerifiableExecution` helpers to record DB/API/storage/library side effects under the current operation when verifiable execution is enabled
- `IEmbeddings` — For generating vector embeddings (see below)
- All services registered in the server's DI container
- `ILogger<T>` — For structured logging

### Plugin Handle Access

Plugins can access the hosting agent's handle components via `IFabrCoreAgentHost`:

Compatibility naming: `GetUserHandle()` and `HasUserHandle()` are legacy method names. They return/check the principal handle prefix used for routing, storage partitioning, and ACL checks.

```csharp
public Task InitializeAsync(AgentConfiguration config, IServiceProvider serviceProvider)
{
    _agentHost = serviceProvider.GetRequiredService<IFabrCoreAgentHost>();

    var fullHandle = _agentHost.GetHandle();        // "principal123:assistant"
    var principalHandle = _agentHost.GetUserHandle();   // "principal123"
    var agent      = _agentHost.GetAgentHandle();   // "assistant"
    var (p, a)     = _agentHost.GetParsedHandle();  // ("principal123", "assistant")
    var hasPrincipalHandle = _agentHost.HasUserHandle();      // true

    return Task.CompletedTask;
}
```

### Attested External Effects

Plugins and tools often call external APIs or update databases. SPIFFE/signing does not observe those side effects automatically. To make an external effect part of verifiable execution, use the `FabrCore.Sdk.VerifiableExecution` helper extensions around the actual DB/API/storage/library call.

```csharp
using FabrCore.Core.VerifiableExecution;
using FabrCore.Sdk.VerifiableExecution;

private IVerifiableExecutionContext? _evidence;

public Task InitializeAsync(AgentConfiguration config, IServiceProvider serviceProvider)
{
    _evidence = serviceProvider.GetService<IVerifiableExecutionContext>();
    return Task.CompletedTask;
}

public async Task<string> UpdateOrder(string orderId, string status)
{
    var result = await _evidence.RecordDbEffectAsync(
        operation: "UpdateOrder",
        target: "Orders",
        subject: orderId,
        effect: () => UpdateDatabase(orderId, status),
        metadata: new Dictionary<string, string?>
        {
            ["db.system"] = "sqlserver",
            ["row_key_hash"] = VerifiableExecutionHash.HashText(orderId),
            ["status_hash"] = VerifiableExecutionHash.HashText(status)
        });

    return $"Updated {result.Value} row(s).";
}
```

The helper records success/failure metadata, duration, safe hashes, and rethrows business exceptions. Evidence recording itself is fail-open. Record hashes/redacted metadata, not secrets or raw customer values. For DB writes that must be audit-grade, prefer a transaction/outbox pattern so the business update and evidence marker commit together. See `fabrcore-spiffe -> external-effects.md`.

### Plugin with Inter-Agent Communication

```csharp
[PluginAlias("coordinator")]
public class CoordinatorPlugin : IFabrCorePlugin
{
    private IFabrCoreAgentHost _agentHost = default!;

    public Task InitializeAsync(AgentConfiguration config, IServiceProvider serviceProvider)
    {
        _agentHost = serviceProvider.GetRequiredService<IFabrCoreAgentHost>();
        return Task.CompletedTask;
    }

    [Description("Delegates a question to a specialist agent and returns their response.")]
    public async Task<string> AskSpecialist(
        [Description("The handle of the specialist agent")] string agentHandle,
        [Description("The question to ask")] string question)
    {
        var request = new AgentMessage { Message = question };
        var response = await _agentHost.SendAndReceiveMessage(request);
        return response.Message ?? "(no response)";
    }
}
```

### Plugin with Status Messages

Plugins can set the agent's heartbeat status message via `IFabrCoreAgentHost.SetStatusMessage()`. This controls the text shown to clients during long-running tool operations (instead of the default "Thinking.."):

```csharp
[PluginAlias("data-sync")]
public class DataSyncPlugin : IFabrCorePlugin
{
    private IFabrCoreAgentHost _agentHost = default!;

    public Task InitializeAsync(AgentConfiguration config, IServiceProvider serviceProvider)
    {
        _agentHost = serviceProvider.GetRequiredService<IFabrCoreAgentHost>();
        return Task.CompletedTask;
    }

    [Description("Sync data from the external API")]
    public async Task<string> SyncData([Description("The dataset to sync")] string dataset)
    {
        _agentHost.SetStatusMessage("Syncing data..");
        try
        {
            // ... long-running operation
            return "Sync complete";
        }
        finally
        {
            _agentHost.SetStatusMessage(null); // revert to default "Thinking.."
        }
    }
}
```

**Best practice:** Always reset the status message to `null` in a `finally` block so it reverts to the default even if the tool throws.

For explicit progress messages rather than heartbeat text, send an `AgentMessage` with `MessageType = SystemMessageTypes.Thinking` and `Kind = MessageKind.OneWay`. Consumers that receive full `AgentMessage` objects should use `message.IsSystemMessage` to recognize `_status`, `_thinking`, `_error`, and other underscore-prefixed control traffic; use `SystemMessageTypes.IsSystemMessage(messageType)` only when working with a raw type string or monitor snapshot.

### Plugin with Disposable Resources

```csharp
[PluginAlias("data-access")]
public class DataAccessPlugin : IFabrCorePlugin, IAsyncDisposable
{
    private HttpClient? _httpClient;

    public async Task InitializeAsync(AgentConfiguration config, IServiceProvider serviceProvider)
    {
        var baseUrl = config.GetPluginSetting("data-access", "BaseUrl")
            ?? throw new InvalidOperationException("data-access:BaseUrl is required");
        _httpClient = new HttpClient { BaseAddress = new Uri(baseUrl) };
    }

    [Description("Fetches data from the configured API endpoint.")]
    public async Task<string> FetchData([Description("API path to query")] string path)
    {
        return await _httpClient!.GetStringAsync(path);
    }

    public async ValueTask DisposeAsync() => _httpClient?.Dispose();
}
```

## Building a Standalone Tool

For simple, stateless operations that don't need initialization or state:

```csharp
using System.ComponentModel;
using FabrCore.Sdk;

public static class UtilityTools
{
    [ToolAlias("format-json")]
    [Description("Format a JSON string with proper indentation")]
    [FabrCoreCapabilities("JSON pretty-printing with standard indentation.")]
    public static string FormatJson(
        [Description("The raw JSON string to format")] string json)
    {
        var parsed = JsonDocument.Parse(json);
        return JsonSerializer.Serialize(parsed, new JsonSerializerOptions { WriteIndented = true });
    }

    [ToolAlias("timestamp")]
    [Description("Get the current UTC timestamp in ISO 8601 format")]
    [FabrCoreCapabilities("UTC timestamp generation in ISO 8601 format.")]
    public static string GetTimestamp()
    {
        return DateTimeOffset.UtcNow.ToString("o");
    }
}
```

### Standalone Tool Rules
- Must be `static` methods in a `static` class
- Decorated with `[ToolAlias("name")]` and `[Description("...")]`
- Auto-discovered from assemblies at startup
- Cannot access `IFabrCoreAgentHost` or DI services (use plugins for that)
- Best for pure functions with no side effects

### Configuring Tools on Agents

```json
{
  "Plugins": ["my-plugin"],              // All tools from the plugin
  "Tools": ["format-json", "timestamp"]  // Specific standalone tools
}
```

## Tool Calling Patterns

### Three Ways to Add Tools

**1. Local tool methods** (defined in the agent class):
```csharp
public override async Task OnInitialize()
{
    var tools = new List<AITool>();
    tools.Add(AIFunctionFactory.Create(SearchDatabase));
    tools.Add(AIFunctionFactory.Create(SendEmail));
    var result = await CreateChatClientAgent("default",
        threadId: config.Handle ?? "default", tools: tools);
}

[Description("Searches the database for records matching the query.")]
private async Task<string> SearchDatabase(string query, int maxResults = 10)
{
    return $"Found {maxResults} results for '{query}'";
}
```

**2. Configured plugins and tools** (resolved from AgentConfiguration):
```csharp
var tools = await ResolveConfiguredToolsAsync();
// Optionally add local tools too
tools.Add(AIFunctionFactory.Create(MyLocalTool));
```

**3. MCP servers** (see fabrcore-mcp skill for details):
```csharp
var tools = await ResolveConfiguredToolsAsync(); // includes MCP tools
```

## Writing Effective Tool Descriptions

The LLM relies on `[Description]` attributes to decide when to call tools:

```csharp
// GOOD — specific, explains when to use, describes parameters
[Description("Searches the product catalog by name or category. Returns up to 20 matching products with prices.")]
public async Task<string> SearchProducts(
    [Description("Search query — can be a product name, category, or keyword")] string query,
    [Description("Maximum number of results (1-50, default 20)")] int limit = 20)

// BAD — vague, unhelpful to the LLM
[Description("Search")]
public async Task<string> Search(string q, int n = 20)
```

**Rules for tool methods:**
- Use `[Description]` on both the method and each parameter
- Method name should be descriptive (the LLM sees it)
- Return `string` or `Task<string>` for simplicity
- Complex return types are JSON-serialized automatically
- Return error messages as strings rather than throwing exceptions

## Using IEmbeddings in Plugins

`IEmbeddings` (FabrCore.Sdk) is auto-registered by `AddFabrCoreServer()` and available via DI. It generates vector embeddings using the `"embeddings"` entry in the host's model configuration (`fabrcore.json`, or the cloud server when enabled).

```csharp
public interface IEmbeddings
{
    Task<Embedding<float>> GetEmbeddings(string text);
    Task<IReadOnlyList<Embedding<float>>> GetBatchEmbeddings(IReadOnlyList<string> texts);
}
```

**Example: Plugin that uses embeddings for semantic similarity:**
```csharp
[PluginAlias("semantic")]
public class SemanticPlugin : IFabrCorePlugin
{
    private IEmbeddings _embeddings = default!;

    public Task InitializeAsync(AgentConfiguration config, IServiceProvider serviceProvider)
    {
        _embeddings = serviceProvider.GetRequiredService<IEmbeddings>();
        return Task.CompletedTask;
    }

    [Description("Generate a vector embedding for the given text")]
    public async Task<string> Embed([Description("Text to embed")] string text)
    {
        var result = await _embeddings.GetEmbeddings(text);
        return $"Generated {result.Vector.Length}-dimensional embedding";
    }
}
```

**Requires** a `"embeddings"` entry in the host's `ModelConfigurations` — `fabrcore.json` or cloud-server config (see fabrcore-server skill).

## Using Typed Entity Storage in Plugins

Plugins can use typed entity storage for small JSON-serializable app data that should outlive the current tool call, such as lookup caches, workflow checkpoints, shared system settings, or integration cursors.

```csharp
[PluginAlias("workflow")]
public class WorkflowPlugin : IFabrCorePlugin
{
    private IFabrCoreStorageProvider _storage = default!;
    private IFabrCoreAgentHost _agentHost = default!;

    public Task InitializeAsync(AgentConfiguration config, IServiceProvider serviceProvider)
    {
        _storage = serviceProvider.GetRequiredService<IFabrCoreStorageProvider>();
        _agentHost = serviceProvider.GetRequiredService<IFabrCoreAgentHost>();
        return Task.CompletedTask;
    }

    [Description("Saves the current workflow checkpoint.")]
    public async Task<string> SaveCheckpoint(string workflowId, string status)
    {
        await _storage.UpsertAsync("workflow-checkpoints", workflowId, new
        {
            Agent = _agentHost.GetHandle(),
            Status = status,
            UpdatedUtc = DateTime.UtcNow
        });

        return "Checkpoint saved.";
    }
}
```

Pitfalls:
- In Host DI, principal-handle-free `IFabrCoreStorageProvider` writes to the system partition. Use this for shared/system plugin data.
- For per-principal data, make principal handle partitioning explicit in a Host service or through the Storage HTTP API. Use `fabrcoreAgentHost.GetUserHandle()` as the principal handle when appropriate; the method name is legacy.
- Prefer `GetStateAsync`/`TryGetStateAsync`/`SetState` on the agent for private per-agent state; it is simpler and benefits from grain single-threaded execution. Use `TryGetStateAsync<T>` when a built-in or plugin-backed agent can reset or migrate stale private state after package updates.
- Typed storage is CRUD-only in v1. There is no query/list API, no partial update, and no optimistic concurrency token.
- Do not resolve Orleans `IGrainStorage` in plugin code. Keep Orleans storage details inside FabrCore.Host.

## Plugin Best Practices

1. **Clear descriptions** — Each tool method needs a `[Description]` telling the LLM when and how to use it
2. **Parameter descriptions** — Use `[Description]` on parameters for complex types
3. **Return strings** — The LLM receives the return value as text
4. **Error handling** — Return error messages as strings rather than throwing
5. **Stateful is OK** — Plugins can maintain state between calls within the same agent
6. **Disposable resources** — Implement `IAsyncDisposable` for cleanup
