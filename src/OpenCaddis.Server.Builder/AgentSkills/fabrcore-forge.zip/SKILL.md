---
name: fabrcore-forge
description: >
  Build, host, extend, or troubleshoot FabrCore Forge, the commercial multi-tenant control
  plane for FabrCore clusters. Use for tenant/cluster/environment administration, versioned
  configuration and blueprint distribution, overlays and rollback, API keys, heartbeats,
  the outbound Cloud Server v2 connect queue/proxy, Forge-hosted Surface.Admin, SQL migrations,
  or the free single-cluster versus paid fleet boundary.
---

# FabrCore Forge

Forge is the commercial implementation of the open FabrCore Cloud Server protocol. It provides
hosted administration and fleet operations without making the OSS runtime depend on Forge.

## Boundary

- Keep open contracts and cluster-side protocol code in `C:\repos\FabrCore`.
- Keep `FabrCore.Forge`, `FabrCore.Forge.Contracts`, `FabrCore.Forge.App`,
  `FabrCore.Surface.Admin`, and Forge SQL state in this repository.
- Consume OSS packages at version 1.5.0 or later. Conditional sibling project references are
  local-development conveniences only; package-mode Release builds are authoritative.
- Use `fabrcore-oss-aug2026` for any change that crosses the repository boundary.

## Host Forge

```csharp
builder.Services.AddForgeServer("ForgeDb", options =>
{
    options.AdminRole = "forge-admin";
    options.OperatorRole = "forge-operator";
    options.AdminPolicySchemes.Add("Cookies");
    options.HeartbeatOnlineWindow = TimeSpan.FromMinutes(5);
    options.ConnectCommandTimeout = TimeSpan.FromSeconds(45);
});
```

Call authentication/authorization middleware and map controllers. The `forge` SQL schema is
created by forward-only, applock-guarded migrations. `M003_ConnectChannel` owns the durable
command queue.

## Contracts and admin API

Forge administration interfaces and DTOs live in `FabrCore.Forge.Contracts`, not
`FabrCore.Services.Contracts`. `AddForgeServer` registers `IForgeAdminService`,
`IForgeAdminClient`, and the keyed local client.

REST administration is rooted at `/fabrcoreapi/forge/admin/v1` and requires
`ForgePolicies.Admin`. The API manages:

- tenants, users, and local roles;
- clusters and environments;
- base and environment-overlay config documents;
- version history and rollback;
- cluster keys and status;
- dashboard data.

## Configuration and blueprint distribution

Base and overlay documents merge like appsettings:

- model configurations replace by `name`;
- API keys merge by `alias`;
- settings merge by key;
- an overlay that contains `blueprints` replaces the base rollout set.

Each blueprint deployment carries a principal-scoped canonical `FabrCoreBlueprint` plus
`ApplyOnRefresh`. The cluster applies deployments only after accepting a new configuration
version. Keep the wire shape aligned with the OSS
`FabrCore.Core.CloudServer.CloudConfigurationEnvelope`.

## Outbound connect channel

Clusters long-poll:

- `GET /fabrcore-cloud/v2/connect`
- `POST /fabrcore-cloud/v2/connect/{commandId}/response`

Forge user-facing proxy:

- `/forgeapi/v1/clusters/{clusterId}/proxy/{**path}`

`ConnectCommandService` durably enqueues, leases, expires, and completes commands. It accepts only
FabrCore admin API paths and bounded bodies. The cluster independently enforces loopback-only
execution and substitutes its own local admin bearer key.

`ForgeConnectHttpMessageHandler` lets Forge-hosted Surface.Admin clients use the broker without
an in-process HTTP round trip. It overwrites `x-user-handle` from the authenticated Forge actor.

## Product shape

`Forge:AdminTarget:ClusterId` configures the one cluster shown by the current free-tier console.
Do not turn that fixed target into an implicit unrestricted fleet selector. Multi-cluster
selection, fleet workflows, and entitlement enforcement are paid-product seams.

Forge owns interactive management, hosted Memory/GraphRAG administration, verifiable-execution
and incident workflows, environment rollout/rollback, and commercial adapters. OSS remains
fully usable with local config and open admin APIs.

## Validation

Pack OSS first, then validate the real dependency boundary:

```powershell
dotnet build C:\repos\fabrcore-v365\src\FabrCore-V365.slnx -c Release `
  /p:UseLocalFabrCoreSource=false `
  /p:FabrCoreOssVersion=<local-version>

dotnet run --project C:\repos\fabrcore-v365\src\FabrCore.Forge.Tests\FabrCore.Forge.Tests.csproj `
  -c Release --no-restore
```

Set `FABRCORE_FORGE_TEST_CONNECTION_STRING` for SQL migrations, config, keys, heartbeat, and
connect end-to-end coverage. Report those tests as skipped when the variable is absent.
